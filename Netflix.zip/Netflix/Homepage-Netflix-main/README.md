# Homepage-Netflix
Homepage of Netflix: A simple website having similar homepage that of Netflix using using HTML and CSS.
